#!/bin/bash
zenity --password --title="Enable webcam"
