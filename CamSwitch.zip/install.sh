#!/bin/bash

if sudo cp -a script/. ~/.Cam_Switch/; then
	printf "\nDone... Now set your shortcut"
	printf "\nSHORTCUT PATH = './.Cam_Switch/cam_switch.sh'\n"
	printf "\nN.B. The files are located in Home/$USER/.Cam_Switch"
	printf "\n     Delete the folder in order to uninstall this script\n\n"
else
	printf "\nThere was an error...\n"
fi
